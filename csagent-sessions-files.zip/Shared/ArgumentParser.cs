using CsAgent.Core.Agent;
using CsAgent.Core.Llm;
using CsAgent.Core.Memory;

namespace CsAgent.Shared;

/// <summary>
/// Parsed CLI arguments — clean record, no parsing logic mixed in.
/// </summary>
public sealed record AgentArguments(
    string MemoryFile,
    string? ModelOverride,
    string? McpUrl,
    string? TaskSlug,
    int Port,
    bool IsUiMode,
    bool IsLeanUiMode,
    bool IsDryRun,
    bool ShowHelp,
    bool ShowVersion,
    bool ShowDoc,
    int MaxRetries = 6,
    int RetryDelayMs = 1000,
    bool UsePropMem = true,
    string PropositionFile = "agent_propositions.json",
    bool Distill = true,
    bool IsApiMode = false,
    bool AutoApprove = false,
    string Host = "localhost",
    string? ApiKey = null,
    string? Endpoint = null,
    string? VisionModel = null,
    bool Quiet = false,
    string? CodeModel = null,
    string? ChatModel = null,
    bool AutoRoute = true,
    bool InitRouting = false,
    string? ExplainRouting = null,
    string? RulesFolder = null,
    string? Language = null,
    string? Prompt = null,
    int ContextChars = 96_000,
    bool CompactToolResults = true,
    bool Verbose = false,
    bool AllTools = false,
    IReadOnlyList<string>? McpUrls = null,
    IReadOnlyList<string>? McpStdio = null,
    IReadOnlyList<string>? McpHeaders = null,
    string? McpConfig = null,
    string? Workflow = null,
    bool Fresh = false,
    int CompressChars = 0,
    bool Compress = true);

/// <summary>
/// Pure argument parsing — no side effects, no console output.
/// </summary>
public static class ArgumentParser
{
    public static AgentArguments Parse(string[] args)
    {
        var isUiMode = args.Contains("--ui");
        var isLeanUiMode = args.Contains("--leanui");
        var isDryRun = args.Contains("--dry-run");
        var showHelp = args.Contains("--help") || args.Contains("-h") || args.Contains("/?");
        var showVersion = args.Contains("--version");
        var showDoc = args.Contains("--doc");
        // --workflow <file>: runs a CSFlow workflow; "" (flag without a file) lets the program print its usage.
        var workflow = args.Contains("--workflow") ? GetValue(args, "--workflow") ?? "" : null;
        var memFile = GetMemoryFile(args);
        var modelOverride = GetModelOverride(args);
        var mcpUrls = GetValues(args, "--mcp", "--mcp-url");
        var mcpConfig = GetValue(args, "--mcp-config") ?? Environment.GetEnvironmentVariable("CSAGENT_MCP_CONFIG");
        if (string.IsNullOrWhiteSpace(mcpConfig)) mcpConfig = null;
        var mcpUrl = mcpUrls.Count > 0 ? mcpUrls[0] : Environment.GetEnvironmentVariable("CSAGENT_MCP_URL");
        var taskSlug = GetValue(args, "--task");
        var port = GetPort(args);
        // A CSFlow workflow looks for the agent on port 8080 unless a step says otherwise.
        if (workflow is not null && !args.Contains("--port") && !args.Contains("-p")) port = 8080;
        var maxRetries = GetInt(args, "--max-retries", RetryPolicy.Default.MaxAttempts);
        var retryDelayMs = GetInt(args, "--retry-delay", RetryPolicy.Default.BaseDelayMs);
        var contextChars = GetInt(args, "--context-chars", ContextBudget.DefaultMaxChars);
        var usePropMem = !args.Contains("--no-propmem");
        var propositionFile = GetValue(args, "--prop") ?? "agent_propositions.json";
        var distill = !args.Contains("--no-distill");
        // The agent steps of a workflow are not a conversation: their own memory file, and no distilling.
        if (workflow is not null)
        {
            distill = false;
            if (memFile == MemoryPaths.DefaultName) memFile = "csflow_worker";   // unless a memory file was named
        }
        var isApiMode = args.Contains("--api");
        var autoApprove = args.Contains("--yes") || args.Contains("-y") || args.Contains("--auto-approve");
        var host = GetValue(args, "--host") ?? ApiSecurity.DefaultHost;
        var apiKey = GetValue(args, "--api-key") ?? Environment.GetEnvironmentVariable("CSAGENT_API_KEY");
        if (string.IsNullOrEmpty(apiKey)) apiKey = null;
        var quiet = args.Contains("--quiet") || args.Contains("-q");
        var endpoint = GetValue(args, "--endpoint") ?? Environment.GetEnvironmentVariable("CSAGENT_ENDPOINT");
        if (string.IsNullOrWhiteSpace(endpoint)) endpoint = null;
        var visionModel = GetValue(args, "--vision-model") ?? Environment.GetEnvironmentVariable("CSAGENT_VISION_MODEL");
        if (string.IsNullOrWhiteSpace(visionModel)) visionModel = null;
        var codeModel = GetValue(args, "--code-model") ?? Environment.GetEnvironmentVariable("CSAGENT_MODEL_CODE");
        if (string.IsNullOrWhiteSpace(codeModel)) codeModel = null;
        var chatModel = GetValue(args, "--chat-model") ?? Environment.GetEnvironmentVariable("CSAGENT_MODEL_CHAT");
        if (string.IsNullOrWhiteSpace(chatModel)) chatModel = null;
        var autoRoute = !args.Contains("--no-route") && !RoutingDisabledByEnv();
        var initRouting = args.Contains("--init-routing");
        // "" (flag without a message) lets the command print its usage.
        var explainRouting = args.Contains("--explain-routing") ? GetValue(args, "--explain-routing") ?? "" : null;
        var rulesFolder = GetValue(args, "--rules") ?? Environment.GetEnvironmentVariable("CSAGENT_ROUTING_RULES");
        if (string.IsNullOrWhiteSpace(rulesFolder)) rulesFolder = null;

        // "" (flag without a text) lets the program print its usage.
        var prompt = args.Contains("--prompt") ? GetValue(args, "--prompt") ?? "" : null;
        var language = GetValue(args, "--lang");
        if (string.IsNullOrWhiteSpace(language)) language = null;

        return new AgentArguments(memFile, modelOverride, mcpUrl, taskSlug,
            port, isUiMode, isLeanUiMode, isDryRun,
            showHelp, showVersion, showDoc, maxRetries, retryDelayMs, usePropMem, propositionFile, distill,
            isApiMode, autoApprove, host, apiKey, endpoint, visionModel, quiet,
            codeModel, chatModel, autoRoute, initRouting, explainRouting, rulesFolder, language, prompt,
            contextChars, !args.Contains("--no-compact"), args.Contains("--verbose"), args.Contains("--all-tools"),
            mcpUrls, GetValues(args, "--mcp-stdio"), GetValues(args, "--mcp-header"),
            mcpConfig, workflow, args.Contains("--fresh"),
            GetInt(args, "--compress-threshold", 0), !args.Contains("--no-compress"));
    }

    private static string GetMemoryFile(string[] args)
    {
        for (int i = 0; i < args.Length; i++)
            if (args[i] is "--mem" or "--session" && i + 1 < args.Length) return args[i + 1];

        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] is "--model" or "--mcp" or "--mcp-url" or "--port"
                          or "-p" or "--max-retries" or "--retry-delay"
                          or "--task" or "--prop" or "--host" or "--api-key"
                          or "--endpoint" or "--vision-model" or "--code-model" or "--chat-model"
                          or "--explain-routing" or "--rules" or "--lang" or "--prompt" or "--context-chars"
                          or "--mcp-url" or "--mcp-stdio" or "--mcp-header" or "--mcp-config" or "--workflow"
                          or "--compress-threshold")
            { i++; continue; }

            if (args[i] != "--ui" && args[i] != "--leanui"
                && args[i] != "--dry-run" && !args[i].StartsWith("-"))
                return args[i];
        }
        return MemoryPaths.DefaultName;
    }

    private static string? GetModelOverride(string[] args) => GetValue(args, "--model");

    /// <summary>CSAGENT_ROUTING=off (or 0, false, no) turns the automatic model choice off.</summary>
    private static bool RoutingDisabledByEnv()
    {
        var v = Environment.GetEnvironmentVariable("CSAGENT_ROUTING")?.Trim();
        return v is not null && (v.Equals("off", StringComparison.OrdinalIgnoreCase) || v == "0"
            || v.Equals("false", StringComparison.OrdinalIgnoreCase) || v.Equals("no", StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Every value of an option that may be repeated (<c>--mcp a --mcp b</c>).</summary>
    private static List<string> GetValues(string[] args, params string[] names)
    {
        var values = new List<string>();
        for (int i = 0; i < args.Length - 1; i++)
            if (names.Contains(args[i], StringComparer.OrdinalIgnoreCase))
                values.Add(args[i + 1]);
        return values;
    }

    private static string? GetValue(string[] args, params string[] names)
    {
        for (int i = 0; i < args.Length - 1; i++)
            if (names.Contains(args[i], StringComparer.OrdinalIgnoreCase))
                return args[i + 1];
        return null;
    }

    private static int GetPort(string[] args)
    {
        for (int i = 0; i < args.Length; i++)
            if ((args[i] == "--port" || args[i] == "-p") && i + 1 < args.Length)
                if (int.TryParse(args[i + 1], out var p) && p > 0 && p < 65536)
                    return p;
        return 5050;
    }

    /// <summary>Reads an integer-valued option, falling back to defaultValue.</summary>
    private static int GetInt(string[] args, string name, int defaultValue)
    {
        for (int i = 0; i < args.Length - 1; i++)
            if (args[i] == name && int.TryParse(args[i + 1], out var v) && v > 0)
                return v;
        return defaultValue;
    }
}