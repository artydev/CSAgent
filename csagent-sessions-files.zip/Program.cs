using CsAgent.Core.Agent;
using CsAgent.Core.Llm;
using System.Text;
using CsAgent.Infrastructure.Clipboard;
using CsAgent.Presentation.LeanUI;
using CsAgent.Presentation.Tui;
using CsAgent.Presentation.Web;
using CsAgent.Shared;

namespace CsAgent;

public static class Program
{
    public const string Version = "0.9.20";

    [STAThread]
    public static int Main(string[] args)
    {
        try { Console.OutputEncoding = Encoding.UTF8; }
        catch { }

        var parsed = ArgumentParser.Parse(args);

        Loc.Set(parsed.Language);
        LlmConfig.Configure(parsed.Endpoint, parsed.VisionModel, parsed.CodeModel, parsed.ChatModel, parsed.AutoRoute);
        RoutingRules.FolderOverride = parsed.RulesFolder;
        ContextBudget.Configure(parsed.ContextChars, parsed.CompactToolResults);
        ContextBudget.ConfigureCompression(parsed.CompressChars, parsed.Compress);
        ToolSelector.Configure(parsed.AllTools);

        if (parsed.ShowHelp) { HelpDisplay.Show(Version); return 0; }
        if (parsed.ShowVersion) { Console.WriteLine($"CSAgent version {Version}"); return 0; }
        if (parsed.ShowDoc) { DocDisplay.Show(); return 0; }
        if (parsed.InitRouting) return RoutingCli.Init(Console.Out, parsed.RulesFolder);
        if (parsed.ExplainRouting is not null) return RoutingCli.Explain(Console.Out, parsed.ExplainRouting);

        try { McpSettings.Configure(McpSettings.FromArguments(parsed)); }
        catch (McpConfigException ex)
        {
            Console.Error.WriteLine($"Error: {ex.Message}");
            return 2;
        }

        if (parsed.Prompt is not null && string.IsNullOrWhiteSpace(parsed.Prompt))
        {
            Console.Error.WriteLine(Loc.T("Usage: csagent --prompt \"<text>\"   (runs one request, prints the answer and exits)"));
            return 2;
        }

        if (parsed.Workflow is not null && string.IsNullOrWhiteSpace(parsed.Workflow))
        {
            Console.Error.WriteLine(Loc.T("Usage: csagent --mcp-config mcp.json --workflow <file>   (runs a CSFlow workflow of its workflows folder)"));
            return 2;
        }

        if (parsed.Workflow is not null)
            return WorkflowHost.Run(parsed);

        // Headless API mode: no clipboard, no browser, no UI assets.
        if (parsed.IsApiMode)
            return ApiHost.Run(parsed);

        using var clipboard = new WindowsClipboardMonitor();
        clipboard.Start();

        if (parsed.IsLeanUiMode)
            LeanUIHost.Run(parsed, clipboard);
        else if (parsed.IsUiMode)
            WebHost.Run(parsed, clipboard);
        else
            return TuiHost.RunAsync(parsed, clipboard).GetAwaiter().GetResult();

        return 0;
    }
}